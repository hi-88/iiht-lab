Spring MVC Validation
=====================

Spring MVC validation example using JSR-303 annotations and custom validation annotations

This repo is a companion to my [Spring MVC Form Validation Tutorial](http://codetutr.com/2013/05/28/spring-mvc-form-validation/)
